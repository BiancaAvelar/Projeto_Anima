package StepDefinition;		


import org.openqa.selenium.By;		
import org.openqa.selenium.WebDriver;		
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;


import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;



public class Steps {				

    WebDriver driver;			
    		
    
    @Given("^Dado que eu navego para a pagina de busca do banco de questoes$")					
    public void open_the_Firefox_and_launch_the_application() throws Throwable							
    {		
       System.setProperty("webdriver.gecko.driver", "C://Users//Isaias//Downloads//geckodriver-v0.23.0-win64//geckodriver.exe");					
       driver= new FirefoxDriver();					
       driver.manage().window().maximize();			
       driver.get("https://opentdb.com/browse.php");					
    }		

    @When("^Digitar Science: Computers no campo de busca e clicar no botao buscar$")					
    public void digitar_buscar() throws Throwable 							
    {		
       driver.findElement(By.name("query")).sendKeys("Science: Computers");       
       driver.findElement(By.className("btn-default")).click();
       
       
    }		

    @Then("^Verificar mensagem de erro$")					
    public void Reset_the_credential() throws Throwable 							
    {		
    	String texto =  driver.findElement(By.className("alert-danger")).getText();
    	System.out.println("Resultado:  " + texto);
    	Assert.assertEquals("No questions found.", texto);
    }

    
    @Given("^Dado que eu navego para a pagina de busca do banco de questoes2$")					
    public void open_the_Firefox_and_launch_the_application2() throws Throwable							
    {		
       System.setProperty("webdriver.gecko.driver", "C://Users//Isaias//Downloads//geckodriver-v0.23.0-win64//geckodriver.exe");					
       driver= new FirefoxDriver();					
       driver.manage().window().maximize();			
       driver.get("https://opentdb.com/browse.php");					
    }		

    @When("^Digitar Science: Computers no campo de busca e clicar no botao buscar2$")					
    public void digitar_buscar2() throws Throwable 							
    {		
       driver.findElement(By.name("query")).sendKeys("Science: Computers");  
       driver.findElement(By.id("type")).sendKeys("Category");
       driver.findElement(By.className("btn-default")).click();
    }		

    @Then("^Aparecer a listagem de questoes com 25 itens e controle de paginacao2$")					
    public void Reset_the_credential2() throws Throwable 							
    {		
    	
    	if(driver.findElement(By.className("pagination-lg"))!= null){
    		System.out.println("OK: Pagina��o encontrada!");
    		}else{
    		System.out.println("ERRO: Pagina��o n�o existe!");
    		}
       
    }	
    
    
    
    @Given("^Dado que eu navego para a pagina de busca do banco de questoes3$")					
    public void open_the_Firefox_and_launch_the_application3() throws Throwable							
    {		
       System.setProperty("webdriver.gecko.driver", "C://Users//Isaias//Downloads//geckodriver-v0.23.0-win64//geckodriver.exe");					
       driver= new FirefoxDriver();					
       driver.manage().window().maximize();			
       driver.get("https://opentdb.com/browse.php");					
    }		

    @When("^Digitar Harvard no campo de busca e clicar no botao buscar3$")					
    public void digitar_buscar3() throws Throwable 							
    {		
       driver.findElement(By.name("query")).sendKeys("Harvard");  
       driver.findElement(By.className("btn-default")).click();
    }		

  
    
    @Then("^Aparecer a listagem de questoes com menos de 26 itens e nao exibir controle de paginacao3$")										
    public void Reset_the_credential3() throws Throwable 							
    {		
    	
    	if(driver.findElements(By.className("pagination-lg")).size() != 0){
    		System.out.println("ERRO: Existe pagina��o! Verificar.");
    		}else{
    		System.out.println("OK: Sem controle de pagina��o.");
    		}
    	
       
    }	
    
   
   
   
}	

